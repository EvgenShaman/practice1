package task7.Decorator;

public interface Component {
    String operation();
}
