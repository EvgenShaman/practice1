package task7.Decorator;

public class CComponent implements Component{

    @Override
    public String operation() {
        return "I'm blue";
    }
}
