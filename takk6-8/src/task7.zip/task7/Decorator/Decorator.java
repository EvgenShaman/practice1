package task7.Decorator;

public interface Decorator {
    String addedState = null;
    String operation();
}
