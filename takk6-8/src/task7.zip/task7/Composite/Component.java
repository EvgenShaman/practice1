package task7.Composite;

public interface Component {
    void operation();
}
